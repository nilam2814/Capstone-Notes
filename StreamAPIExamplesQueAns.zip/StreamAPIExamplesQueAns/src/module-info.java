module StreamAPIExamplesQueAns {
}