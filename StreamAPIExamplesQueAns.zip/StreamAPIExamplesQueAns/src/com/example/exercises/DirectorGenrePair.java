package com.example.exercises;

import com.example.domain.Director;
import com.example.domain.Genre;

record DirectorGenrePair(Director director,Genre genre) { }
