package com.example.exercises;

import com.example.domain.Country;


public record CountryCityCountPair(Country country,int count) { }
