package com.training.org;

class InstitutionalPlan extends Plan {
	// @override
	public void getRate() {
		rate = 5.50;
	}
}
// end of InstitutionalPlan class.