package com.training.org;

public interface Prototype {
	public Prototype getClone();
}
