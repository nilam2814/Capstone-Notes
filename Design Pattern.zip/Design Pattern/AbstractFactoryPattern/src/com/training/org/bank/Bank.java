package com.training.org.bank;

import java.io.*;

public interface Bank {
	String getBankName();
}