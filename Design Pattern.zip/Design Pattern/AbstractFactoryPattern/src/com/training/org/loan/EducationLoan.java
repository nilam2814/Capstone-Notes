package com.training.org.loan;

public class EducationLoan extends Loan {
	public void getInterestRate(double r) {
		rate = r;
	}
}// End of the EducationLoan class.