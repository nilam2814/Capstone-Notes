package com.training.org.loan;

public class HomeLoan extends Loan {
	public void getInterestRate(double r) {
		rate = r;
	}
}// End of the HomeLoan class.