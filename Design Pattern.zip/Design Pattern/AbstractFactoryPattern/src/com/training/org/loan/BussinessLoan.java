package com.training.org.loan;

public class BussinessLoan extends Loan {
	public void getInterestRate(double r) {
		rate = r;
	}

}// End of the BusssinessLoan class.